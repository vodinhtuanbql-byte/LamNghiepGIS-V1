# Lâm Nghiệp GIS V1 – Android alpha2

## Đã làm
- Android project.
- GPS permission + đọc vị trí gần nhất.
- Chọn `.TAB` bằng Android Storage Access Framework.
- Phân tích Definition Table của MapInfo TAB.
- Đọc `.DAT` theo cấu trúc dBase/MapInfo để lấy thuộc tính.
- Nhận diện bộ `.TAB + .DAT + .MAP + .ID (+ .IND)`.
- Đóng gói bộ BQL_HT2024 thật trong assets để kiểm thử.

## BQL_HT2024 đã kiểm tra bằng dữ liệu thật
- 4.401 bản ghi thuộc tính.
- 51 trường.
- DAT header 1.665 bytes; record 1.702 bytes.
- ID 17.604 bytes = 4 x 4.401.
- MAP 2.540.544 bytes.

## Còn thiếu trong alpha2
Chưa đánh dấu hoàn tất phần giải mã hình học `.MAP/.ID`. MapInfo Native là một bộ nhiều file; `.MAP` chứa map objects và `.ID` liên kết object với bản ghi. GDAL/OGR có driver MapInfo TAB chính thức để đọc native TAB. Vì vậy bước tiếp theo là đóng gói MITAB/GDAL cho `arm64-android` hoặc một reader MITAB tương thích, rồi đưa polygon thật lên bản đồ.

GDAL documentation hiện nêu Android có thể build GDAL cho `arm64-android` bằng vcpkg; driver MapInfo hỗ trợ đọc/ghi TAB native. 
