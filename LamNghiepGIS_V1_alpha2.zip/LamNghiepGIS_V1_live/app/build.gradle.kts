plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "vn.lamnghiep.gis"; compileSdk = 35
    defaultConfig { applicationId = "vn.lamnghiep.gis"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.0-alpha2" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
