package vn.lamnghiep.gis

import android.content.Context
import java.io.File
import java.nio.charset.Charset
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class TabField(val name: String, val type: Char, val width: Int, val decimals: Int)
data class TabDefinition(val name: String, val charset: String, val fields: List<TabField>)
data class TabBundle(val tab: File, val dat: File?, val map: File?, val id: File?, val ind: File?)
data class DbfTable(val recordCount: Int, val recordLength: Int, val headerLength: Int, val fields: List<TabField>, val rows: List<Map<String,String>>)

object MapInfoReader {
    private val tabField = Regex("^\\s{4}([A-Za-z0-9_]+)\\s+(Decimal|Float|Char)\\s*(?:\\((\\d+)(?:,\\s*(\\d+))?\\))?\\s*;")

    fun bundle(base: File): TabBundle {
        val stem = base.nameWithoutExtension
        val dir = base.parentFile ?: base
        fun f(ext: String) = File(dir, "$stem.$ext").takeIf { it.exists() }
        return TabBundle(base, f("DAT"), f("MAP"), f("ID"), f("IND"))
    }

    fun parseTab(file: File): TabDefinition {
        val text = file.readText(Charset.forName("ISO-8859-1"))
        val name = file.nameWithoutExtension
        val charset = Regex("!charset\\s+(.+)", RegexOption.IGNORE_CASE).find(text)?.groupValues?.get(1)?.trim().orEmpty()
        val fields = text.lineSequence().mapNotNull { line ->
            tabField.find(line)?.let { m -> TabField(m.groupValues[1], m.groupValues[2][0], m.groupValues[3].ifEmpty { "0" }.toInt(), m.groupValues[4].ifEmpty { "0" }.toInt()) }
        }.toList()
        return TabDefinition(name, charset, fields)
    }

    fun readDat(dat: File, fields: List<TabField>, maxRows: Int = 25): DbfTable {
        val h = dat.inputStream().buffered().use { input ->
            val b = ByteArray(32); input.read(b); b
        }
        fun u16(o: Int) = ByteBuffer.wrap(h, o, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xffff
        fun u32(o: Int) = ByteBuffer.wrap(h, o, 4).order(ByteOrder.LITTLE_ENDIAN).int
        val recordCount = u32(4)
        val headerLength = u16(8)
        val recordLength = u16(10)
        val physicalFields = mutableListOf<TabField>()
        dat.inputStream().buffered().use { input ->
            input.skip(32)
            val bytes = ByteArray(32)
            while (input.read(bytes) == 32) {
                if ((bytes[0].toInt() and 0xff) == 0x0d) break
                val name = bytes.copyOfRange(0, 11).toString(Charsets.US_ASCII).trimEnd('\u0000',' ')
                val type = bytes[11].toInt().toChar()
                val width = bytes[16].toInt() and 0xff
                val decimals = bytes[17].toInt() and 0xff
                physicalFields += TabField(name, type, width, decimals)
            }
        }
        val readFields = if (fields.size == physicalFields.size) fields else physicalFields
        val rows = ArrayList<Map<String,String>>(minOf(maxRows, recordCount))
        dat.inputStream().buffered().use { input ->
            var skipped = 0L
            while (skipped < headerLength) { val n = input.skip(headerLength - skipped); if (n <= 0) break; skipped += n }
            val rec = ByteArray(recordLength)
            repeat(minOf(maxRows, recordCount)) {
                if (input.read(rec) != recordLength) return@repeat
                val row = LinkedHashMap<String,String>(); var pos = 1
                readFields.forEach { f ->
                    val len = f.width.coerceAtLeast(0)
                    val end = minOf(pos + len, rec.size)
                    val value = if (pos < end) String(rec, pos, end-pos, Charset.forName("windows-1252")).trimEnd('\u0000',' ') .trim() else ""
                    row[f.name] = value; pos += len
                }
                rows += row
            }
        }
        return DbfTable(recordCount, recordLength, headerLength, readFields, rows)
    }

}
