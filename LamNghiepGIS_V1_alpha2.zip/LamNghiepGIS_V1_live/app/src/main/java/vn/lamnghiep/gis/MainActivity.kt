package vn.lamnghiep.gis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.io.File

class MainActivity : AppCompatActivity() {
    private val pickCode = 7001
    private lateinit var status: TextView
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,20,20,20) }
        val title = TextView(this).apply { text = "🌲 LÂM NGHIỆP GIS V1"; textSize = 25f; gravity = Gravity.CENTER; setPadding(0,0,0,16) }
        status = TextView(this).apply { text = "Chưa nạp dữ liệu"; textSize = 16f }
        info = TextView(this).apply { text = "Android • GPS • MapInfo TAB • Offline\n\nBản V1 này đọc cấu trúc TAB và bảng thuộc tính DAT. Bộ đọc hình học MAP/ID sẽ được gắn ở bước kế tiếp."; textSize = 15f; setPadding(0,14,0,14) }
        val open = Button(this).apply { text = "🗂️ Mở bộ MapInfo (.TAB)" }
        val gps = Button(this).apply { text = "📍 Lấy GPS hiện tại" }
        val collect = Button(this).apply { text = "➕ Ghi điểm hiện trường" }
        val table = Button(this).apply { text = "🌲 Xem thuộc tính BQL_HT2024" }
        root.addView(title); root.addView(status); root.addView(info); root.addView(open); root.addView(gps); root.addView(table); root.addView(collect)
        setContentView(root)

        open.setOnClickListener { pickTab() }
        gps.setOnClickListener { readGps() }
        table.setOnClickListener { loadBundledTable() }
        collect.setOnClickListener { Toast.makeText(this,"V1: sẽ lưu tọa độ + thời gian + ảnh + ghi chú.",Toast.LENGTH_LONG).show() }
    }

    private fun pickTab() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream","text/plain","*/*")) }
        startActivityForResult(i, pickCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "Đã chọn: ${uri.lastPathSegment}\nLưu ý: MapInfo là bộ nhiều file (.TAB/.DAT/.MAP/.ID). Hãy đặt cả bộ cùng thư mục để bước import xử lý đầy đủ."
    }

    private fun loadBundledTable() {
        val dir = File(cacheDir, "BQL_HT2024").apply { mkdirs() }
        val tab = File(dir,"BQL_HT2024.TAB")
        assets.open("BQL_HT2024.TAB").use { it.copyTo(tab.outputStream()) }
        val def = MapInfoReader.parseTab(tab)
        val dat = File(dir,"BQL_HT2024.DAT")
        assets.open("BQL_HT2024.DAT").use { it.copyTo(dat.outputStream()) }
        val dbf = MapInfoReader.readDat(dat, def.fields, 3)
        status.text = "BQL_HT2024: ${dbf.recordCount} bản ghi • ${def.fields.size} trường"
        info.text = dbf.rows.mapIndexed { i, row ->
            "#${i+1}  TK=${row["TK"]}  KHOANH=${row["KHOANH"]}  LO=${row["LO"]}  DTICH=${row["DTICH"]}  CHURUNG=${row["CHURUNG"]}"
        }.joinToString("\n\n") + "\n\nMapInfo geometry: MAP/ID đã được đóng gói; parser hình học sẽ gắn ở bước tiếp theo."
    }

    private fun readGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10); return
        }
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val p = runCatching { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) }.getOrNull()
        info.text = if (p != null) "GPS\nLat: %.7f\nLon: %.7f\nĐộ cao: %.1f m\nĐộ chính xác: %.1f m".format(p.latitude,p.longitude,p.altitude,p.accuracy) else "Chưa có fix GPS. Hãy bật vị trí và ra nơi thoáng rồi thử lại."
    }
}
